import './App.css';
import View from './View';

const App = () => {
  return (
    <div className="App">
      <>
         <View/>
      </>
    </div>
  );
}

export default App;
